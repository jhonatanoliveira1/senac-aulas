<?php
include ("conecta.php");

$USUARIO = $_POST["username"];
$SENHA = $_POST["usersenha"];


/*echo $USUARIO."<BR>".$SENHA; //debug para verficar recebimento de dados */

$query=" INSERT INTO  usuarios values ('','$USUARIO';MD5('$SENHA'))";

mysqli_query ($conexao,$query) or die("Erro de banco de dados");

echo "<script>alert('Usuário Cadastrado com sucesso');location.href=\"index2.html\";</script>";

mysqli_close($conexao);

?>