<?php

 define('HOST','localhost');
 define('USUARIO','root');
 define('SENHA','');
 define('DB','websistema');


 /*
 $HOST = 'localhost';
 $USUARIO = 'root';
 $SENHA = '';
 $DB ='websistema';
*/

 $conexao = mysqli_connect(HOST,USUARIO,SENHA,DB);
  //if (!$conexao); {
   // die('Não pode conectar: '. mysqli_error());
 // }

 

?>