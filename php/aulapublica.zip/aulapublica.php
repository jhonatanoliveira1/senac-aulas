<?php

class Aula {
     public  $materia
     public  $programacao
     private $nota 
     protected $provafinal

     private function  avaliacao();{
        echo "avaliacao";
     }
 
     $teste = new Aula 
    $teste = situacoes();
    $teste -> avaliacao();


     
     private function notas();{
        echo "notas";
     }

     $provas = new Aulas 
     $provas = valorenota ();
     $provas -> notas();





     public function nota();{
        echo "nota";
     }
      
}

$professor = new Aula();
$professor-> Estudar();
$professor-> materia = "php";
$professor-> nota();


?> 